
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Direction Classes</title>

    <link href="css/rgen_min.css" rel="stylesheet">
    <link href="css/default.css" rel="stylesheet">
 	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">

 	<style type="text/css">
 		.mr-b-small{
 			margin-bottom: 3.25rem;
 		}

 		.title[data-rgen-sm*="medium"]{
 			font-size: 35px;
 		}
 	</style>
</head>

<body>
<div id="page" data-linkscroll='y'>
	<section class="pd-tb-medium bg-dark" data-rgen-sm="pd-tb-small"> 
		<div class="container small typo-light align-c" data-animate-in="fadeIn">
			<img src="images/logo-light.png" alt="R.Genesis.Art" class="max-px-w150 mr-auto mr-b-small">

			<!-- <h5 class="title small bold-n txt-upper" data-rgen-sm="small">Free webinar</h5> -->
			<h2 class="title f-2 large lh-1 mr-b-small" data-rgen-sm="medium mr-b-30">Are you looking for Best Coaching Centre ?</h2>
			<p class="title-sub small w75 mr-auto" data-rgen-sm="small">We are a team of Cambridge accredited trainers following international learning methodology</p>

			<!--=================================
			= Counter block
			==================================-->
			<div class="inline-block pd-micro bg-default txt-white bold-4 z1 pos-rel shadow-large mini fs20" style="padding-left: 50px; padding-right: 50px; display: block; border-radius: 5px;">
				<div></div>	
				<a href="" style="display: block;">Register Now and get a BONUS (Formula Book for FREE)</a>
			</div><br><br>
			<p style="font-weight: bold;font-size: 20px;">OFFER Valid for first 100 Registrations</p>

			<p >Located in Bhandup, Mulund, Powai (Mumbai)</p>
		</div>

		<div class="bg-holder full-wh z0">
			<!-- Overlay -->
			<b data-bgholder="overlay" class="full-wh z5" data-bgcolor="rgba(45, 51, 69, 0.8)"></b>
			<!-- Background video -->
			<div data-bgholder="video" class="videobg z4 full-wh"></div>
			<!-- bg slider -->
			<div data-bgholder="slider" class="full-wh z3" data-rgen-sm="h100">
				<div class="bgslider full-wh"></div>
			</div>
			<!-- Parallax image -->
			<div data-bgholder="parallax" class="full-wh z2"></div>
			<!-- Background image -->
			<b data-bgholder="bg-img" class="full-wh bg-cover bg-cc z1" data-bg="images/homepage-bg.png"></b>
		</div>

	</section>


	<section class="pd-tb-small" data-rgen-sm="pd-tb-small align-c">
		<div class="container small">
			<div class="row mb20">
				<div class="col-md-6" data-animate-in="fadeInLeft">
					<h2 class="f-2 txt-upper lh-1 title" data-rgen-sm="medium">Our Champions who Raise the bar</h2>
					<p class="title-sub mini" data-rgen-sm="small">7 out of 10 students uplifted from 60%-- >>> 90 % in grades - Not only in GRADES but We at Direction Classes Focus on making you a better learner by Active learning ,Practising HARD and peer to peer discussions.</p>

					<div class="info-obj img-l g30 small pd-b-tiny mr-0" data-rgen-sm="align-l">
						<div class="img txt-default"><span class="iconwrp"><i class="fa fa-diamond"></i></span></div>
						<div class="info">
							<h3 class="title mini mr-b-micro">Digital marketing tips</h3>
							<p class="mr-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
						</div>
					</div><!-- info box -->

					<div class="info-obj img-l g30 small pd-b-tiny mr-0" data-rgen-sm="align-l">
						<div class="img txt-default"><span class="iconwrp"><i class="pe-7s-way"></i></span></div>
						<div class="info">
							<h3 class="title mini mr-b-micro">Trending designs</h3>
							<p class="mr-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
						</div>
					</div><!-- info box -->

					<div class="info-obj img-l g30 small pd-b-tiny mr-0" data-rgen-sm="align-l">
						<div class="img txt-default"><span class="iconwrp"><i class="pe-7s-network"></i></span></div>
						<div class="info">
							<h3 class="title mini mr-b-micro">Marketing work flows</h3>
							<p class="mr-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
						</div>
					</div><!-- info box -->

					<div class="info-obj img-l g30 small pd-b-tiny mr-0" data-rgen-sm="align-l">
						<div class="img txt-default"><span class="iconwrp"><i class="pe-7s-home"></i></span></div>
						<div class="info">
							<h3 class="title mini mr-b-micro">Detail overview</h3>
							<p class="mr-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
						</div>
					</div><!-- info box -->
				</div><!-- // END : column //  -->
				
				<div class="col-md-5 offset-md-1" data-animate-in="fadeInRight">

					<div class="info-obj img-l mid g20 small pd-20 bg-default typo-light">
						<div class="img"><span class="iconwrp txt-white"><i class="fa fa-calendar"></i></span></div>
						<div class="info">
							<h3 class="title mini mr-b-10">Date : March 12, 2017</h3>
							<p class="mr-0">Time: 11 AM GMT | 2 PM GMT</p>
						</div>
					</div><!-- info box -->


					<!-- form-block -->
					<div class="form-block bg-dark pd-tiny typo-light">
						<h3 class="title small txt-white bold-n align-c">Book Now</h3>
						<form action="process.php" method="post">
							<div class="field-wrp">
								<div class="form-group">
									<input class="form-control form-control-light bdr-2 rd-0" data-label="Name" required data-msg="Please enter name." type="text" name="Name" placeholder="Enter your name">
								</div>
								<div class="form-group">
									<input class="form-control form-control-light bdr-2 rd-0" data-label="Email" required data-msg="Please enter email." type="email" name="Email" placeholder="Enter your email">
								</div>
								<div class="form-group">
									<input class="form-control form-control-light bdr-2 rd-0" data-label="Mobile Number" type="number" name="Mobile" placeholder="Enter your Mobile Number">
								</div>
								<div class="form-group">
								
									<textarea class="form-control form-control-light bdr-2 rd-0" data-label="Message" type="text" name="Message" placeholder="Enter your Message"></textarea>
								</div>
							</div>
							<button type="submit" name="submit" class="btn solid btn-white block rd-0"> Submit</button>
						</form><!-- / form -->
					</div><!-- / form block -->
					
				</div><!-- // END : column //  -->
			</div><!-- // END : row //  -->
		</div><!-- // END : Container //  -->

		<!--
=================================
= Background holder
=================================
-->
<div class="bg-holder full-wh z0">
	<!-- Overlay -->
	<b data-bgholder="overlay" class="full-wh z5" data-bgcolor="rgba(45, 51, 69, 0)"></b>
	<!-- Parallax image -->
	<div data-bgholder="parallax" class="full-wh z2"></div>
	<!-- Background image -->
	<b data-bgholder="bg-img" class="full-wh bg-cover bg-cc z1"></b>
</div>
	</section>
	<!-- ************** END : Features section **************  -->

	<!--
	************************************************************
	* Testimonials
	************************************************************ -->
	<section class="pd-tb-small bg-gray" data-rgen-sm="pd-tb-small">
		<div class="container small">
			<div class="row gt40 mb20">
				<div class="col-md-6" data-animate-in="fadeInLeft">
					<div class="info-obj img-l g30 small">
						<div class="img -mr-r-40 pos-rel z1 mr-t-tiny"><img src="images/person1.jpg" class="rd mr-auto"></div>
						<div class="info pd-tiny bg-white shadow-tiny">
							<p class="fs16">Lorem ipsum dolor sit amet, optio exercitationem id, sapiente ea rerum illo, labore voluptatem voluptates! Ea repellendus omnis tempora, impedit numquam. Voluptas atque, dignissimos quisquam.</p>

							<h3 class="title mini bold-n mr-0">Oupsum dolor</h3>
							<em class="fs12">Creative Director</em>
						</div>
					</div><!-- info box -->
				</div><!-- // END : column //  -->
				
				<div class="col-md-6" data-animate-in="fadeInRight">
					<div class="info-obj img-l g30 small">
						<div class="img -mr-r-40 pos-rel z1 mr-t-tiny"><img src="images/person2.jpg" class="rd mr-auto"></div>
						<div class="info pd-tiny bg-white shadow-tiny">
							<p class="fs16">Lorem ipsum dolor sit amet, optio exercitationem id, sapiente ea rerum illo, labore voluptatem voluptates! Ea repellendus omnis tempora, impedit numquam. Voluptas atque, dignissimos quisquam.</p>

							<h3 class="title mini bold-n mr-0">Oupsum dolor</h3>
							<em class="fs12">Creative Director</em>
						</div>
					</div><!-- info box -->
				</div><!-- // END : column //  -->
			</div><!-- // END : row //  -->
		</div><!-- // END : Container //  -->

		<!--
=================================
= Background holder
=================================
-->
<div class="bg-holder full-wh z0">
	<!-- Overlay -->
	<b data-bgholder="overlay" class="full-wh z5" data-bgcolor="rgba(45, 51, 69, 0)"></b>
	<!-- Parallax image -->
	<div data-bgholder="parallax" class="full-wh z2"></div>
	<!-- Background image -->
	<b data-bgholder="bg-img" class="full-wh bg-cover bg-cc z1"></b>
</div>
	</section>
	<!-- ************** END : Testimonials **************  -->
	
	<!--
	************************************************************
	* Footer section
	************************************************************ -->
	<footer class="pd-tb-mini bg-dark" data-rgen-sm="pd-tb-small">
		<div class="container small typo-light align-c" data-rgen-sm="align-c">
			<!--=========================================
			=  Social links
			=============================================-->
			<a href="#" target="_blank" class="sq30 fs16 mr-r-4 rd-2 bg-glass-light-01 iconbox btn-white"><i class="fa fa-facebook-f"></i></a>
			<a href="#" target="_blank" class="sq30 fs16 mr-r-4 rd-2 bg-glass-light-01 iconbox btn-white"><i class="fa fa-twitter"></i></a>
			<a href="#" target="_blank" class="sq30 fs16 mr-r-4 rd-2 bg-glass-light-01 iconbox btn-white"><i class="fa fa-google"></i></a>
			<a href="#" target="_blank" class="sq30 fs16 mr-r-4 rd-2 bg-glass-light-01 iconbox btn-white"><i class="fa fa-youtube"></i></a>
			<a href="#" target="_blank" class="sq30 fs16 mr-r-4 rd-2 bg-glass-light-01 iconbox btn-white"><i class="fa fa-tumblr"></i></a>
			<hr class="light">
			<p class="mr-0"><a href="https://goo.gl/ZMxnYs" target="_blank">R.Gen - landing pages</a> &copy; <span class="copyright-year"></span></p>
		</div>
	</footer><!-- / Footer section -->
	<!-- ************** END : Footer section **************  -->

	<!-- JavaScript --> 
	<script>
	/* Use fonts with class name in sequence => f-1, f-2, f-3 .... */
	var fgroup = [
		'Open Sans:400,300,300italic,400italic,600,700,600italic,700italic,800,800italic',
		'Roboto:300,400,500,700,900'
	];
	</script>
	
</div>
<script src="js/rgen_min.js"></script>
</body>
</html>