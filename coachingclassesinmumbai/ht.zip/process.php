<?php 
	$host = "localhost";
	$username = "root";
	$password = "";
	try{
	$conn = new PDO('mysql:host=localhost;dbname=dc_lp',$username,$password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}

catch(PDOException $e){
	echo $e->getMessage();
}
?>


<?php 
		$name = $_POST['Name'];
		$email = $_POST['Email'];
		$mobile = $_POST['Mobile'];
		$message = $_POST['Message'];
		$sub = "Enuiry Form Landing Page";
	if(isset($_POST['submit'])){
		$query = $conn->prepare("INSERT INTO contact(Name,Email,Mobile,Message) VALUES(:Name, :Email, :Mobile, :Message)");
		$query->bindParam(':Name',$name);
		$query->bindParam(':Email',$email);
		$query->bindParam(':Mobile',$mobile);
		$query->bindParam(':Message',$message);
		$query->execute();
		}
	

	else{
	echo "<script>window.open('index.php','_self')</script>";
	}


	require('mailin.php');
		$email_bdoy = 
		"
		<strong><h3 style='text-align:center;'>Enuiry Form Landing Page</h3><br>
		<strong>Name :- </strong>".$name."<br>
		<strong>Email :- </strong>".$email."<br>
		<strong>Mobile Number :- </strong>".$mobile."<br>
		<strong>Message :- </strong>".$message."<br>
		";

		$mailin = new Mailin("https://api.sendinblue.com/v2.0","kG7vd1NOMz9wLfEj");
		$data1 = array("to" => array("kunal1071996@gmail.com"=>"Kunal Soni"),
						"form"=>array("cvtodc@gmail.com","CVDC"),
						"subject"=>"Mail From DC Landing Page",
						"html"=>$email_bdoy);

		$data2=array("email" =>$email,
        "attributes" => array("FIRSTNAME"=>$name,"SMS"=>$mobile,"SUBJECTS"=>$sub),
        "listid" => array(120));	
        
    	var_dump($mailin->send_email($data1));
		var_dump($mailin->create_update_user($data2));
	/*	echo "<script>womdpw.open('index.php','_self')</script>";
		echo "<script>alert('Form Submited Successfully')</script>";*/
?>