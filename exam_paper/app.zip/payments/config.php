<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="maroonen_maroonentertainment";
$conn=new mysqli($host,$dbuser,$dbpass,$db);

/*
$dbuser="ibpaspeh_maroonen";
$dbpass="@maroon.in123##";
$host="localhost";
$db="ibpaspeh_maroonentertainment";
$conn=new mysqli($host,$dbuser,$dbpass,$db);
*/
?>