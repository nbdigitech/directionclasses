<h3>Course Enquiry From Website</h3>
<p>Name :- {{$name}}</p>

<p>Email :- {{$email}}</p>

<p>Subject :- {{$subject}}</p>

<p>Contact Number :- {{$Phone}}</p>

<p>Message :- {{$Message}}</p>