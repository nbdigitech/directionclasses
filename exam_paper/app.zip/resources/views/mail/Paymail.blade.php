<h3>Book Purchase</h3>
<p>Name :- {{$Name}}</p>
<p>Email :- {{$Email}}</p>
<p>Contact :- {{$Phone}}</p>
<p>Ebook Download Now :- {{$url}}</p>