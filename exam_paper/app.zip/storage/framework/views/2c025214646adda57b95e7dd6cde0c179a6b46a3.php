
<?php echo $__env->make('layouts.Header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="">
<div id="wrapper">
  <!-- preloader -->
  
<?php echo $__env->make('layouts.Menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="main-content">
    <section class="inner-header divider parallax layer-overlay overlay-white-8" data-bg-img="<?php echo e(url('/')); ?>/public/frontend/images/bg/bg6.jpg">
      <div class="container pt-100 pb-100">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title">About Us</h2>
              <ol class="breadcrumb text-center mt-10">
                <li><a href="<?php echo e(route('Index')); ?>">Home</a></li>
                
                <li class="active text-theme-colored">About Us</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
    
     <section class="bg-lighter">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
                      
              <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">CHANAKYA<span class="text-theme-colored3"> PUBLIC SCHOOL</span></h2>
              <p class="font-15" style="text-align:justify;">
                 We, at  Chanakya Public School  look at children as individuals and not as a class.  We groom and nourish each child independently, for all require distinct attention. We build an atmosphere where each child explores multiple activities, and experiences challenges to find his own strengths. <br><br> Chanakya  is an institution that looks beyond imparting just knowledge.  It takes a holistic approach, focusing on the overall development of the child, by giving him an environment that nurtures and instill  strong values of dignity, decency and respect for human life. We believe in nurturing and enriching the mind and soul of the child. This is why we lay such strong emphasis on looking beyond the set parameters of bookish education. <br><br> Through activities like music, drama, sports and adventure, we help students find their inner strength, develop a high self-esteem and make them self actualised  individuals.   Life demands a healthy and intelligent mind, with a healthy body. Our curriculum has been  especially designed to make it inclusive; where physical, emotional and mental needs are met significantly.

                  </p>
            </div>

            <div class="col-sm-4 col-md-4" style="margin-top: 80px;">
                      <img src="<?php echo e(url('/')); ?>/public/frontend/images/chanakya_about.png" style="border-radius: 5px;">
            </div>
          </div>
        </div>
      </div>
    </section>

    
    


 
    <section id="about">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
            <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Facilitators</h2>
              
              <p class="font-15" style="text-align: justify;">At Chanakya, experienced educationists, psychologists, teachers, artists and sports-persons have come together to frame a curriculum that draws from the CBSE curriculum; but is bench-marked with various international curricula for their standards & methodologies and is customized to the Indian environment. Unlike the traditional method of teaching, where the focus is on the trainer, our approach is learner-centric. We maintain a democratic and participative culture with mutual respect and appreciation for individual values. <br><br>
 
There is a constant endeavor at our end to keep ourselves at par with the ever changing environment. Various orientation workshops are held at regular intervals for teachers to absorb the vision, align with the values and take ownership for our mission and the curriculum. The school takes special responsibility in equipping children with the right attitude and skills that would help them become winners. Modern infrastructure, continuous realignment of curriculum, pedagogy and skilled teachers are the ingredients of Chanakya Public School - the new era school. As a concerned parent, your search for an effective collaborator to attend to your child's scholastic and versatile needs concludes at Chanakya.

   
</p>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
             
             
                
              <img src="<?php echo e(url('/')); ?>/public/frontend/images/facilitators.png" style="border-radius: 5px; margin-top: 80px;">
                <!-- Application Form Validation Start -->
             
            </div>
          </div>
        </div>
      </div>
    </section>





    <section class="bg-lighter">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
          <div class="col-xs-12 col-sm-4 col-md-4 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
             <img src="<?php echo e(url('/')); ?>/public/frontend/images/about/collegebuilding.jpg" style="width: 100%; height:200px">
            </div>
            <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Chanakya Academy - <span class="text-theme-colored3">Founder Society</span></h2>
              <p class="font-15">Raised in 1993, Chanakya Academy has come a long way; Chanakya decided to focus on skill based vocational and professional undergraduate level programs linked with job opportunities. </p>

            <p>A professionally managed educational society, Chanakya is headed by Dr Wg Cdr Subhash Sindhwani, PhD in Human Resources Management and Master’s degree in Industrial Engineering from India’s premier institute NITIE with 40 years of extensive experience as a trainer, consultant and entrepreneur. </p>

            <p>Chanakya, an innovator, is interested in changing the landscape of higher education making it vocational, practical, skill oriented and job linked.</p>

            </div>
            
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->
 <?php echo $__env->make('layouts.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a> </div>
<!-- end wrapper --> 

<!-- Footer Scripts --> 
<!-- JS | Custom script for all pages --> 
<script src="<?php echo e(url('/')); ?>/public/frontend/js/custom.js"></script>

</body>

<!-- Mirrored from thememascot.net/demo/personal/f/edupoints/v3/demo/page-about2.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 10 Jan 2019 08:00:52 GMT -->
</html>