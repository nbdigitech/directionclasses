<div class="sidebar" data-color="rose" data-background-color="black" data-image="<?php echo e(url('/')); ?>/public/assets/img/sidebar-1.jpg">

      <div class="logo">
       
        <a href="<?php echo e(route('Admin/Dashboard')); ?>" class="simple-text logo-normal">
         <img src="<?php echo e(url('/')); ?>/public/assets/img/logo.png" style="margin-left: 10px;">
        </a>
      </div>
      <div class="sidebar-wrapper">
        <div class="user">
          <div class="photo">
            <img src="<?php echo e(url('/')); ?>/public/assets/img/faces/admin-image-png-3.png" />
          </div>
          <div class="user-info">
            <a data-toggle="collapse" href="#collapseExample" class="username">
              <span>
                <?php echo e(Auth::user()->name); ?>

              </span>
            </a>
            
          </div>
        </div>
        <ul class="nav">
          <li class="nav-item active ">
            <a class="nav-link" href="<?php echo e(route('Admin/Dashboard')); ?>">
              <i class="material-icons">dashboard</i>
              <p> Dashboard </p>
            </a>
          </li>
         
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('Admin/Category')); ?>">
              <i class="material-icons">apps</i>
              <p> Category </p>
            </a>
          </li>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('Admin/Image')); ?>">
              <i class="material-icons">image</i>
              <p> Gallery Image </p>
            </a>
          </li>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('Admin/Video')); ?>">
              <i class="material-icons">image</i>
              <p> Gallery Videos </p>
            </a>
          </li>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('Admin/News')); ?>">
              <i class="material-icons">widgets</i>
              <p> Event </p>
            </a>
          </li>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('Admin/Admission')); ?>">
              <i class="material-icons">tables</i>
              <p>Admission </p>
            </a>
          </li>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('Admin/Contact')); ?>">
              <i class="material-icons">phone</i>
              <p> Contacts </p>
            </a>
          </li>
        </ul>
      </div>
    </div>