<h3>Admission Enquiry</h3>
<p>Name :- <?php echo e($name); ?></p>
<p>Email :- <?php echo e($email); ?></p>
<p>Contact :- <?php echo e($contact); ?></p>
<p>Class :- <?php echo e($class); ?></p>