<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('MainSection'); ?>
<div class="content">
<div class="content">
<div class="container-fluid">
  <div class="row">
                          <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-stats">
                              <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                  <i class="material-icons">weekend</i>
                                </div>
                                <p class="card-category">Contacts </p>
                                <h3 class="card-title"><?php echo e($contact_count); ?></h3>
                              </div>
                              <div class="card-footer" style="display: block;">
                                <div class="stats">
                                  
                                  <a href="<?php echo e(route('Admin/Contact')); ?>" style="display: block;">Click Here Full Details</a>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-stats">
                              <div class="card-header card-header-rose card-header-icon">
                                <div class="card-icon">
                                  <i class="material-icons">equalizer</i>
                                </div>
                                <p class="card-category">Event </p>
                                <h3 class="card-title"><?php echo e($news_count); ?></h3>
                              </div>
                              <div class="card-footer">
                                <div class="stats">
                                   <a href="<?php echo e(route('Admin/News')); ?>" style="display: block;">Click Here To View All Event</a>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="card card-stats">
                              <div class="card-header card-header-success card-header-icon">
                                <div class="card-icon">
                                  <i class="material-icons">store</i>
                                </div>
                                <p class="card-category">Admission</p>
                                <h3 class="card-title"><?php echo e($admission_count); ?></h3>
                              </div>
                              <div class="card-footer">
                                <div class="stats">
                                    <a href="<?php echo e(route('Admin/Admission')); ?>" style="display: block;">Click Here To View All Admission</a>
                                </div>
                              </div>
                            </div>
                          </div>
                         
                        </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>