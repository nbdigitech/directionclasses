
<?php echo $__env->make('layouts.Header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="">
<div id="wrapper">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <div class="dfg"><i></i><i></i><i></i><i></i></div>
      </div>
    </div>
  </div>
  
<?php echo $__env->make('layouts.Menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="main-content">
    <section class="inner-header divider parallax layer-overlay overlay-white-8" data-bg-img="<?php echo e(url('/')); ?>/public/frontend/images/bg/bg6.jpg">
      <div class="container pt-100 pb-100">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title">About</h2>
              <ol class="breadcrumb text-center mt-10">
                <li><a href="<?php echo e(route('Index')); ?>">Home</a></li>
                
                <li class="active text-theme-colored">About</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
    
     <section class="bg-lighter">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
                      
              <div class="col-sm-10 col-md-10">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Welcome to  - <span class="text-theme-colored3">CHANAKYA PUBLIC SCHOOL</span></h2>
              <p class="font-15" style="text-align:justify;">
                  We, at  Chanakya Public School  look at children as individuals and not as a class.  
              We groom and nourish each child independently, for all require distinct attention. We build an atmosphere where each child explores multiple activities, and experiences challenges to find his own strengths.
              Chanakya  is an institution that looks beyond imparting just knowledge. <br><br>  It takes a holistic approach, focusing on the overall development of the child, by giving him an environment that nurtures and instill  strong values of dignity, decency and respect for human life. We believe in nurturing and enriching the mind and soul of the child.
              This is why we lay such strong emphasis on looking beyond the set parameters of bookish education........
              Through activities like music, drama, sports and adventure, we help students find their inner strength, develop a high self-esteem and make them self actualised  individuals.   Life demands a healthy and intelligent mind, with a healthy body. 
              <br><br>
              At Chanakya, experienced educationists, psychologists, teachers, artists and sports-persons have come together to frame a curriculum that draws motional and mental needs are met significantly.from the CBSE curriculum; but is bench-marked with various international curricula for their standards & methodologies and is customized to the Indian environment. Unlike the traditional method of teaching, where the focus is on the trainer, our approach is learner-centric. We maintain a democratic and participative culture with mutual respect and appreciation for individual values. 
    <br>There is a constant endeavor at our end to keep ourselves at par with the ever changing environment. Various orientation workshops are held at regular intervals for teachers to absorb the vision, align with the values and take ownership for our mission and the curriculum.
<br><br>
The school, next to the family, takes special responsibility in equipping children with the right attitude and skills that would help them become winners. Modern infrastructure, continuous realignment of curriculum, pedagogy and committed and skilled teachers are the ingredients of Mind Tree - the new era school. 
<br><br>
As a concerned parent, your search for an effective collaborator to attend to your child's scholastic and versatile needs concludes at Chanakya.

                  </p>

            </div>
            
        
            
            
          </div>
        </div>
      </div>
    </section>

    
    
    <section id="about">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
            <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Chairman<span class="text-theme-colored3">Message</span></h2>
              <img src="http://chanakyacommunitycollege.com/public/frontend/images/subhash_sindhwani.jpg" style="float: left; padding-right: 20px; margin-top: 5px;">
              <p class="font-15">We invite community, industry, business houses, professionals, employers, parents and the students to help us design, deliver various vocational programs to the mutual benefit of society, economy and the community. 
              </p>
              <p>Education is too serious business to be left to the Government or Educators alone; there is an urgent need for closer interaction between educational institutions and the community.</p>
              <p class="font-15">Education is a joint responsibility - we welcome all who have interest in the field of vocational education to come forward and be a part of skill building. </p>

              <p>Skills are fundamental for creation of wealth and wellness of human society and we are committed to skill building to the world class levels.</p>

            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
              <h3 class="mt-0 mb-0 pt-15 pb-15 text-white text-center bg-theme-colored">Enquiry Now</h3>
             <div class="p-20 bg-gray-lighter form-boxshadow">
                <!-- Appilication Form Start-->
                <?php if(session()->has('success')): ?>
              <div class="alert alert-success" style="background-color:#4BAF4E;color:white;">
                <?php echo e(session()->get('success')); ?>

                <a href="#" class="close" aria-label="close" data-dismiss="alert">x</a>
              </div>
              <?php endif; ?>
                <!-- Appilication Form Start-->
                <form action="<?php echo e(route('Enquiry/Store')); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <div class="row">
                    <div class="col-sm-12">
                      <div class="form-group mb-20">
                        <input placeholder="Enter Name" type="text" id="reservation_name" name="Name" required class="form-control" required>
                      </div>
                    </div>
                    <div class="col-sm-12">
                      <div class="form-group mb-20">
                        <input placeholder="Email" type="email" required id="reservation_email" name="Email" class="form-control">
                      </div>
                    </div>
                    <div class="col-sm-12">
                      <div class="form-group mb-20">
                        <input placeholder="Contact" type="text" id="reservation_phone" name="Phone" class="form-control" required>
                      </div>
                    </div>
                  
                   
                    <div class="col-sm-12">
                      <div class="form-group">
                        <textarea placeholder="Enter Message" rows="2" class="form-control required" name="Message" id="form_message" aria-required="true" required></textarea>
                      </div>
                    </div>
                    <div class="col-sm-12">
                      <div class="form-group mb-0 mt-10">
                        <input name="form_botcheck" class="form-control" type="hidden" value="">
                        <button type="submit" class="btn btn-theme-colored btn-lg btn-block" data-loading-text="Please wait...">Submit Request</button>
                      </div>
                    </div>
                  </div>
                </form>
                <!-- Application Form End-->

                <!-- Application Form Validation Start-->
                <script type="text/javascript">
                  $("#reservation_form").validate({
                    submitHandler: function(form) {
                      var form_btn = $(form).find('button[type="submit"]');
                      var form_result_div = '#form-result';
                      $(form_result_div).remove();
                      form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                      var form_btn_old_msg = form_btn.html();
                      form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                      $(form).ajaxSubmit({
                        dataType:  'json',
                        success: function(data) {
                          if( data.status == 'true' ) {
                            $(form).find('.form-control').val('');
                          }
                          form_btn.prop('disabled', false).html(form_btn_old_msg);
                          $(form_result_div).html(data.message).fadeIn('slow');
                          setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                        }
                      });
                    }
                  });
                </script>
                <!-- Application Form Validation Start -->
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>



    <section class="bg-lighter">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
          <div class="col-xs-12 col-sm-4 col-md-4 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
             <img src="<?php echo e(url('/')); ?>/public/frontend/images/about/collegebuilding.jpg" style="width: 100%; height:200px">
            </div>
            <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Chanakya Academy - <span class="text-theme-colored3">Founder Society</span></h2>
              <p class="font-15">Raised in 1993, Chanakya Academy has come a long way; Chanakya decided to focus on skill based vocational and professional undergraduate level programs linked with job opportunities. </p>

            <p>A professionally managed educational society, Chanakya is headed by Dr Wg Cdr Subhash Sindhwani, PhD in Human Resources Management and Master’s degree in Industrial Engineering from India’s premier institute NITIE with 40 years of extensive experience as a trainer, consultant and entrepreneur. </p>

            <p>Chanakya, an innovator, is interested in changing the landscape of higher education making it vocational, practical, skill oriented and job linked.</p>

            </div>
            
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Mission -->
   <!--  <section class="bg-lighter">
      <div class="container pb-70 pb-sm-60">
        <div class="section-title">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="text-center line-height-1 mt-0">Why<span class="text-theme-colored3"> Choose</span> Us</h2>
              <p class="text-center">Lorem ipsum dolor simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row equal-height">
            <div class="col-sm-4 col-md-4">
              <div class="icon-box bg-white text-center clearfix m-0 pr-20 pl-20 pt-30 pb-20 mb-40">
                <a href="#" class="icon icon-circled icon-md flip mb-20"> 
                  <i class="fa fa-desktop font-32 text-white"></i> 
                </a>
                <h3 class="icon-box-title mt-5 mb-15 letter-space-1 line-height-1">Best Lab</h3>
                <p>Lorem ipsum dolor sit amet elit. Duis erat nec. Ut lobortis, magna nec rhoncus, neque quam mattis ipsum, vel erat velit at diam.</p>
                <a class="text-black-999" href="#">Read More...</a>
              </div>
            </div>
            <div class="col-sm-4 col-md-4">
              <div class="icon-box bg-white text-center clearfix m-0 pr-20 pl-20 pt-30 pb-20 mb-40">
                <a href="#" class="icon icon-circled icon-md flip mb-20">
                  <i class="fa fa-user font-32 text-white"></i> 
                </a>
                <h3 class="icon-box-title mt-5 mb-15 letter-space-1 line-height-1">Best Teachers</h3>
                <p>Lorem ipsum dolor sit amet elit. Duis erat nec. Ut lobortis, magna nec rhoncus, neque quam mattis ipsum, vel erat velit at diam.</p>
                <a class="text-black-999" href="#">Read More...</a>
              </div>
            </div>
            <div class="col-sm-4 col-md-4">
              <div class="icon-box bg-white text-center clearfix m-0 pr-20 pl-20 pt-30 pb-20 mb-40">
                <a href="#" class="icon icon-circled icon-md flip mb-20">
                  <i class="fa fa-money font-32 text-white"></i> 
                </a>
                <h3 class="icon-box-title mt-5 mb-15 letter-space-1 line-height-1">Best Library</h3>
                <p>Lorem ipsum dolor sit amet elit. Duis erat nec. Ut lobortis, magna nec rhoncus, neque quam mattis ipsum, vel erat velit at diam.</p>
                <a class="text-black-999" href="#">Read More...</a>
              </div>
            </div> 
          </div>
        </div>
      </div>
    </section> -->





    <!-- Section:  -->
   <!--  <section>
      <div class="container pb-sm-70">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
              <h2 class="mt-0 line-height-1">Faculty <span class="text-theme-colored3">Members</span></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Acque quidem eaque, amet doloribus, error inventore, quisquam totam magni cumque.</p>
            </div>
          </div>
        </div>
        <div class="section-content text-center">
          <div class="row">
            <div class="col-sm-6 col-md-3 mb-sm-30">
              <div class="team-block bg-light pt-10 pb-15">
                <div class="team-thumb"><img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/images/team/1.png" alt="">
                </div>
                <div class="info">
                  <div class="pt-10 pb-10 bg-theme-colored2">
                    <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                    <h6 class="mt-0 mb-0 text-white">Manager</h6>
                  </div>
                  <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel consectetur.</p>
                  <ul class="styled-icons icon-theme-colored icon-circled icon-dark icon-sm mt-15 mb-0">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-skype"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 mb-sm-30">
              <div class="team-block bg-light pt-10 pb-15">
                <div class="team-thumb"><img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/images/team/2.png" alt="">
                </div>
                <div class="info">
                  <div class="pt-10 pb-10 bg-theme-colored">
                    <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                    <h6 class="mt-0 mb-0 text-white">Manager</h6>
                  </div>
                  <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel consectetur.</p>
                  <ul class="styled-icons icon-theme-colored3 icon-circled icon-dark icon-sm mt-15 mb-0">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-skype"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 mb-sm-30">
              <div class="team-block bg-light pt-10 pb-15">
                <div class="team-thumb"><img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/images/team/3.png" alt="">
                </div>
                <div class="info">
                  <div class="pt-10 pb-10 bg-theme-colored3">
                    <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                    <h6 class="mt-0 mb-0 text-white">Manager</h6>
                  </div>
                  <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel consectetur.</p>
                  <ul class="styled-icons icon-theme-colored icon-circled icon-dark icon-sm mt-15 mb-0">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-skype"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-3 mb-sm-30">
              <div class="team-block bg-light pt-10 pb-15">
                <div class="team-thumb"><img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/images/team/4.png" alt="">
                </div>
                <div class="info">
                  <div class="pt-10 pb-10 bg-theme-colored">
                    <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                    <h6 class="mt-0 mb-0 text-white">Manager</h6>
                  </div>
                  <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel consectetur.</p>
                  <ul class="styled-icons icon-theme-colored2 icon-circled icon-dark icon-sm mt-15 mb-0">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-skype"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- Divider: -->
  <!--   <section class="divider parallax layer-overlay overlay-dark-8 text-center" data-bg-img="<?php echo e(url('/')); ?>/public/frontend/images/bg/bg5.jpg" data-parallax-ratio="0.7">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-offset-3">            
            <h2 class="mt-0 text-white">Unlimited Support &amp; Easily Customizable</h2>
            <h4 class="text-white">Subscribe to Connect with us</h4> 
            
           
            <form id="mailchimp-subscription-form3" class="newsletter-form mt-30">
              <label for="mce-EMAIL"></label>
              <div class="input-group">
             
                <span class="input-group-btn">
                  <button type="submit" class="btn btn-colored btn-theme-colored btn-lg m-0" data-height="50px"><i class="fa fa-paper-plane-o font-20" aria-hidden="true"></i>
                  </button>
                </span>
              </div>
            </form>            

            <script type="text/javascript">
              $('#mailchimp-subscription-form3').ajaxChimp({
                  callback: mailChimpCallBack,
                  url: '//thememascot.us9.list-manage.com/subscribe/post?u=a01f440178e35febc8cf4e51f&amp;id=49d6d30e1e'
              });

              function mailChimpCallBack(resp) {
                  // Hide any previous response text
                  var $mailchimpform = $('#mailchimp-subscription-form3'),
                      $response = '';
                  $mailchimpform.children(".alert").remove();
                  if (resp.result === 'success') {
                      $response = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + resp.msg + '</div>';
                  } else if (resp.result === 'error') {
                      $response = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' + resp.msg + '</div>';
                  }
                  $mailchimpform.prepend($response);
              }
            </script>           
          </div>
        </div>
      </div>
    </section> -->

    <!-- Section: blog -->
    <!-- <section id="blog">
      <div class="container pb-70">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
              <h2 class="mt-0 line-height-1 text-center text-uppercase">Latest <span class="text-theme-colored3">News</span></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem temporibus quisquam voluptas natus, provident porro et odio perferendis ipsam, amet sint</p>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-sm-6 col-md-4 col-lg-4">
              <article class="post clearfix maxwidth600 mb-30 border-1px">
                <div class="entry-header-new">
                  <div class="post-thumb thumb"><img src="<?php echo e(url('/')); ?>/public/frontend/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth">
                  </div>
                  <div class="blog-overlay"></div>
                </div>
                <div class="pr-20 pl-20 pb-30 text-center">
                  <h3 class="entry-title mt-20 pt-0"><a class="text-theme-colored" href="#">The Celebration</a></h3>
                  <ul class="list-inline entry-date font-13 mt-5">
                    <li><i class="fa fa-clock-o mr-5 text-theme-colored"></i> Dec - 21 </li>
                    <li><i class="fa fa-map-marker mr-5 text-theme-colored"></i>  121 King Street, Melbourne </li>
                  </ul>
                  <p class="mt-10">Lorem ipsum dolor sit amet. Reiciendis impedit expedita sit deleniti culpa nam fuga neque similique corporis.</p>
                  <a class="btn btn-theme-colored btn-lg btn-flat mt-0 text-white mt-10" href="#">Read more <i class="fa fa-angle-double-right text-theme-colored2"></i></a>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-4">
              <article class="post clearfix maxwidth600 mb-30 border-1px">
                <div class="entry-header-new">
                  <div class="post-thumb thumb"><img src="<?php echo e(url('/')); ?>/public/frontend/images/blog/2.jpg" alt="" class="img-responsive img-fullwidth">
                  </div>
                  <div class="blog-overlay"></div>
                </div>
                <div class="pr-20 pl-20 pb-30 text-center">
                  <h3 class="entry-title mt-20 pt-0"><a class="text-theme-colored" href="#">The Celebration</a></h3>
                  <ul class="list-inline entry-date font-13 mt-5">
                    <li><i class="fa fa-clock-o mr-5 text-theme-colored"></i> Dec - 21 </li>
                    <li><i class="fa fa-map-marker mr-5 text-theme-colored"></i>  121 King Street, Melbourne </li>
                  </ul>
                  <p class="mt-10">Lorem ipsum dolor sit amet. Reiciendis impedit expedita sit deleniti culpa nam fuga neque similique corporis.</p>
                  <a class="btn btn-theme-colored btn-lg btn-flat mt-0 text-white mt-10" href="#">Read more <i class="fa fa-angle-double-right text-theme-colored2"></i></a>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-4">
              <article class="post clearfix maxwidth600 mb-30 border-1px">
                <div class="entry-header-new">
                  <div class="post-thumb thumb"><img src="<?php echo e(url('/')); ?>/public/frontend/images/blog/3.jpg" alt="" class="img-responsive img-fullwidth">
                  </div>
                  <div class="blog-overlay"></div>
                </div>
                <div class="pr-20 pl-20 pb-30 text-center">
                  <h3 class="entry-title mt-20 pt-0"><a class="text-theme-colored" href="#">The Celebration</a></h3>
                  <ul class="list-inline entry-date font-13 mt-5">
                    <li><i class="fa fa-clock-o mr-5 text-theme-colored"></i> Dec - 21 </li>
                    <li><i class="fa fa-map-marker mr-5 text-theme-colored"></i>  121 King Street, Melbourne </li>
                  </ul>
                  <p class="mt-10">Lorem ipsum dolor sit amet. Reiciendis impedit expedita sit deleniti culpa nam fuga neque similique corporis.</p>
                  <a class="btn btn-theme-colored btn-lg btn-flat mt-0 text-white mt-10" href="#">Read more <i class="fa fa-angle-double-right text-theme-colored2"></i></a>
                </div>
              </article>
            </div>
          </div>
        </div>
      </div>
    </section> -->

  </div>
  <!-- end main-content -->
 <?php echo $__env->make('layouts.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a> </div>
<!-- end wrapper --> 

<!-- Footer Scripts --> 
<!-- JS | Custom script for all pages --> 
<script src="<?php echo e(url('/')); ?>/public/frontend/js/custom.js"></script>

</body>

<!-- Mirrored from thememascot.net/demo/personal/f/edupoints/v3/demo/page-about2.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 10 Jan 2019 08:00:52 GMT -->
</html>