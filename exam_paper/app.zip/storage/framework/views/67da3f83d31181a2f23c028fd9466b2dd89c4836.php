<h3>Course Enquiry From Website</h3>
<p>Name :- <?php echo e($name); ?></p>

<p>Email :- <?php echo e($email); ?></p>

<p>Subject :- <?php echo e($subject); ?></p>

<p>Contact Number :- <?php echo e($Phone); ?></p>

<p>Message :- <?php echo e($Message); ?></p>