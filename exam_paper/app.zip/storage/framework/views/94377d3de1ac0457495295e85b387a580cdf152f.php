
<?php echo $__env->make('layouts.Header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style type="text/css">
#gender{
      margin-top: 10px;
    }
  @media(max-width: 768px){
    #gender{
      margin-top: 20px;
      margin-bottom: 20px;
    }
  }
</style>
</head>
<body class="">
<div id="wrapper">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <div class="dfg"><i></i><i></i><i></i><i></i></div>
      </div>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div>
  
<?php echo $__env->make('layouts.Menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="main-content"> 
    <!-- Section: home -->
    <section id="home" class="divider parallax layer-overlay overlay-dark-9" data-bg-img="<?php echo e(url('/')); ?>/public/frontend/images/bg/bg6.jpg">
      <div class="display-table">
        <div class="display-table-cell">
          <div class="container pb-100">
            <div class="row">
              <div class="col-md-8 col-md-push-2">
                <div class="text-center mb-60"><a href="#" class=""><img alt="" src="images/logo-wide-white.png"></a></div>
                <div class="bg-lightest border-1px p-25" style="margin-top: -100px;">
                  <h4 class="text-theme-colored text-uppercase m-0">Admission Enquiry Form</h4>
                  <div class="line-bottom mb-30"></div>
                    <?php if(session()->has('success')): ?>
                  <div class="alert alert-success" style="background:#4BAF4E; color:white;">
                    <?php echo e(session()->get('success')); ?>

                    <a href="#" class="close" data-dismiss="alert" area-label="close">x</a>
                    
                  </div>
                  <?php endif; ?>
                  
                  <form class="mt-30" method="post" action="<?php echo e(route('Admission/Store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <input type="text" name="Name" class="form-control" placeholder="Enter Your Child's Name" required>
                        </div>
                      </div>
                      
                       <div class="col-md-6" >
<div class="form-group">
                          <select name="Gender" required class="form-control">
                            <option value="">Select Gender</option>
                           
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Transgender">Transgender</option>
                          </select>
                       </div>
                      </div>

                      

                      <div class="col-md-6">
                        <div class="form-group">
                          <input type="text" name="Age" min="2" class="form-control" placeholder="Child's Age">
                        </div>
                      </div>

                   <!--mobile-->
                   
                   
                      <div class="col-md-6">
                        <div class="form-group">
                          <input type="number" name="Contact" class="form-control" placeholder="Enter Your Mobile Number" required>
                        </div>
                      </div>
                      
                      <div class="col-md-6">
                        <div class="form-group">
                          <input type="text" name="Guardian" class="form-control" placeholder="Parent's Name">
                        </div>
                      </div>

                     

                       <div class="col-md-6">
                        <div class="form-group">
                          <input type="email" name="Email" class="form-control" placeholder="Enter Your Email Address" required>
                        </div>
                      </div>

                      
                      
                      
                         <div class="col-md-6">
                        <div class="form-group">
                          

                          <select name="Class" required class="form-control">
                            <option value="">Select Class</option>
                            <option value="Nursery">Nursery</option>
                            <option value="KG-1">KG-1</option>
                            <option value="KG-2">KG-2</option>
                            <option value="Class-1">Class-1</option>
                            <option value="Class-2">Class-2</option>
                            <option value="Class-3">Class-3</option>
                            <option value="Class-4">Class-4</option>
                            <option value="Class-5">Class-5</option>
                          </select>
                        </div>
                      </div>

                      <div class="col-md-6">
                        <div class="form-group">
                          <input type="text" name="City" class="form-control" placeholder="Enter Your City" required>
                        </div>
                      </div>

                      <div class="col-md-12">
                        <div class="form-group">
                          <textarea class="form-control" name="Address" placeholder="Enter Your Address"></textarea>
                        </div>
                      </div>
                    </div>
                    <div class="form-group mb-0 mt-20">
                      <input name="form_botcheck" class="form-control" type="hidden" value="">
                      <button type="submit" class="btn btn-dark btn-theme-colored" data-loading-text="Please wait..." style="width: 100%;">Submit</button>
                    </div>
                  </form>
                  <!-- Appointment Form Validation-->
                  <script type="text/javascript">
                    $("#appointment_form").validate({
                      submitHandler: function(form) {
                        var form_btn = $(form).find('button[type="submit"]');
                        var form_result_div = '#form-result';
                        $(form_result_div).remove();
                        form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                        var form_btn_old_msg = form_btn.html();
                        form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                        $(form).ajaxSubmit({
                          dataType:  'json',
                          success: function(data) {
                            if( data.status === 'true' ) {
                              $(form).find('.form-control').val('');
                            }
                            form_btn.prop('disabled', false).html(form_btn_old_msg);
                            $(form_result_div).html(data.message).fadeIn('slow');
                            setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                          }
                        });
                      }
                    });
                  </script>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <!-- end main-content -->
 <?php echo $__env->make('layouts.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a> </div>
<!-- end wrapper --> 

<!-- Footer Scripts --> 
<!-- JS | Custom script for all pages --> 
<script src="<?php echo e(url('/')); ?>/public/frontend/js/custom.js"></script>

</body>

<!-- Mirrored from thememascot.net/demo/personal/f/edupoints/v3/demo/page-about2.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 10 Jan 2019 08:00:52 GMT -->
</html>