<?php echo $__env->make('Admin.layouts.Header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="">
  <div class="wrapper">
    <?php echo $__env->make('Admin.layouts.LeftMenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php echo $__env->make('Admin.layouts.TopMenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End Navbar -->
   <?php echo $__env->yieldContent('MainSection'); ?>

</div>
</div>
<?php echo $__env->make('Admin.layouts.Javascript', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>