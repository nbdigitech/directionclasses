
<?php echo $__env->make('layouts.Header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style type="text/css">
  section > .container, section > .container-fluid{
    padding-top: 0px;
  }
</style>
</head>
<body class="">
<div id="wrapper">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <div class="dfg"><i></i><i></i><i></i><i></i></div>
      </div>
    </div>
  </div>
  
<?php echo $__env->make('layouts.Menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="main-content">
    <section class="inner-header divider parallax layer-overlay overlay-white-8" data-bg-img="<?php echo e(url('/')); ?>/public/frontend/images/bg/bg6.jpg">
      <div class="container pt-100 pb-100">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="title">Why Chanakya</h2>
              <ol class="breadcrumb text-center mt-10">
                <li><a href="<?php echo e(route('Index')); ?>">Home</a></li>
                
                <li class="active text-theme-colored">Why Chanakya</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
    <br><br>
    <section id="section2">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
            <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Life  <span class="text-theme-colored3">Skills</span></h2>
              <p class="font-15">
               <div class="col-sm-12 col-md-12 col-lg-12">
<p style="text-align: justify; margin-left: -10px;">
The School Cinema Programme teach life skills through an extremely innovative and
entertaining medium of movies and role plays. <br>

<br>Life skills training is an efficacious tool for empowering the youth to act responsibly,
take initiative and take control of their lives. Life skills include psycho-social
competencies and inter personal skills that help children make decisions, solve
problems, think deeply, communicate effectively, build healthy relationships,
empathy with others and cope with managing their lives in a healthy and productive
manner.
  <br><br>
 es is methods like class discussions, story telling, brainstorming, role plays,
audio-visual activities etc. We encourage young people to learn from their
environment by observing how others behave and what consequences arise from
their behavior. Thus, teaching outside the classroom becomes as important as that
within the walls.
<br><br>
 Excursions, field trips and visits to various organizations like old age
home, blind school etc. are conducted for this purpose. Learning, thus, becomes not
only a fun filled activity, but also enriching one.
              </p>
            </div>
          </div>
      <div class="col-sm-4 col-md-4" style="margin-top: 70px;">
        <img src="<?php echo e(url('/')); ?>/public/frontend/Infrastructure/life_skill.png" style="width: 100%; border-radius: 5px;">
      </div>
  </div>






      <br>
      <div class="row">
          <div class="col-sm-8 col-md-8">
         <h3 style=" color:#F45661;">Sport</h3>
         <p style=" text-align: justify;">The school spots out the latent talents of students and coaches the students to
enable them to participate in various indoor and outdoor games. Ample
opportunities are provided for the development of a harmonious personality. <br><br>
Activities include - Elocution, Rock Climbing, River Crossing, Burma, Dance, Music,
Quizzes, Poster making, extempore Recitation and many more.</p>
</div>
    
    
      <div class="col-sm-4 col-md-4">
        <img src="<?php echo e(url('/')); ?>/public/frontend/Infrastructure/sport.png" style="width: 100%; height: 250px; border-radius: 5px;">
      </div>
  </div>



<br>
<div class="row">
          <div class="col-sm-8 col-md-8">
 <h3 style=" color:#F45661;">Celebrations </h3>
         <p style=" text-align: justify;">We celebrate all festivals and involve all students  right from  the Nursery. They are encouraged to decorate inculcate the feeling of healthy competition, we the school with handicrafts  for Janmashtami, Diwali, Christmas and Id. <br><br>    We encourage and organize different activities for Art To add to the multifarious personality of a child.    We organize  Art, Karate, Science, Yoga, theatre, Western & Classical Dramatics, Creative Dance and Music Classes in Writing, Music and the evenings at regular intervals.
</p>
</div>
<div class="col-sm-4 col-md-4">
  <img src="<?php echo e(url('/')); ?>/public/frontend/images/celebration.png" height="300px">
      </div>
  </div>



<div class="row">
          <div class="col-sm-8 col-md-8">
<h3 style="margin-left: 10px; color:#F45661; text-align: justify;">Infrastructure Facilities:</h3>
         <p style=" text-align: justify; margin-left: 10px;">The Sports Academy focuses on both indoor as well as outdoor sports. Karate,
Yoga, Gymnastics, Kho-Kho, Cricket &amp; Football are just a few of them. An
acoustically designed recording designed for a fun filled, studio &amp; activity rooms with
adequate facilities for yet a rich learning music, dance and drama ensure that the
children&#39;s experience through creative side always finds expression and exposure
and discovery. 
<br><br>
A specially designed sand play area helps to unleash creativity of the
young ones. The Library (Resource Centre) has a large number of carefully chosen
books, reference. A well equipped computer with latest &amp; adequate fleet of
computers with appropriate software and internet connectivity helps students to
explore the world. 100% power back up has been made.
<br><br>
 It has facilities for indoor
sports &amp; other activities. Keeping in mind the prevalent uncertain circumstances,
well-trained security personnel have been deployed to safeguard the campus.
Nursery &amp; Primary Section Well ventilated, spacious classrooms, equipped with
audio-visual &amp; networked computer facility make it an ideal place for learning. 
<br><br>
There
are spacious, aesthetically designed &amp; well maintained playgrounds suitable for
growing children. Classrooms: Well Equipped &amp; Maintained Outdoor Play Areas:
Admission Criterion Minimum Age (as on 1st April of Admission Year): Nursery - 2
Years 9 Months, LKG - 4 Years, UKG - 5 Years. From Class I onwards there will be
a written test for students seeking admission. Only those candidates who clear the

written test will be called for interaction. All the admissions apart from Nursery are
against vacant seats. Nursery admissions are through draw of lots.
</p>
</div>
<div class="col-sm-4 col-md-4" style="margin-top: 50px;">
  <div id="grid" class="gallery-isotope default-animation-effect grid-4 gutter clearfix">
                <!-- Portfolio Item Start -->
            
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/art.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/art.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/art.png">View more</a>
                  </div>
                </div>




                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/art_workshop.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/art_workshop.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/art_workshop.png">View more</a>
                  </div>
                </div>



                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/audio_visual.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/audio_visual.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/audio_visual.png">View more</a>
                  </div>
                </div>




                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/brain_development.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/brain_development.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/brain_development.png">View more</a>
                  </div>
                </div>




                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/celebrations.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/celebrations.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/celebrations.png">View more</a>
                  </div>
                </div>




                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/computer_lab.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/computer_lab.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/computer_lab.png">View more</a>
                  </div>
                </div>





                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/digital_library.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/digital_library.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/digital_library.png">View more</a>
                  </div>
                </div>




                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/hostel_education.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/hostel_education.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/hostel_education.png">View more</a>
                  </div>
                </div>



<!--
                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/life_skill.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/life_skill.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/life_skill.png">View more</a>
                  </div>
                </div>-->



                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/music.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/music.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/music.png">View more</a>
                  </div>
                </div>




                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/play_area.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/play_area.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/play_area.png">View more</a>
                  </div>
                </div>








                <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/sport.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/sport.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/sport.png">View more</a>
                  </div>
                </div>


                 <div class="gallery-item photography">
                  <div class="thumb">
                    <img class="img-fullwidth" src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/student_centered.png" alt="project" style="height:90px;">
                    <div class="overlay-shade"></div>
                    <div class="icons-holder">
                      <div class="icons-holder-inner">
                        <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                          <a data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/student_centered.png"><i class="fa fa-plus"></i></a>
                          
                        </div>
                      </div>
                    </div>
                    <a class="hover-link" data-lightbox="image" href="<?php echo e(url('/')); ?>/public/frontend/infrastructure/student_centered.png">View more</a>
                  </div>
                </div>
                
            
                <!-- Portfolio Item End -->
                
              
                <!-- Portfolio Item End -->
              </div>
      </div>
  





            </div>
          </div>
        </div>
      </div>
    </section>




    <section id="section2">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
            <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Brain <span class="text-theme-colored3">Development</span></h2>
              <p class="font-15">
                Brain is plastic – it has various stages of development and there is a window for
                developing a particular capability of brain and therefore our training programs
                ensure that brain capabilities are developed at the right opportunity because once
                that opportunity is missed, it is lost for ever. Center for Brain Health Training is an
                active part of our program.
              </p>

              <br>

              <h3 style="color:#F45661;">Art &amp; Brain Workshop</h3>
              <p>School incorporates Art and Brain program in it’s curriculum to ensure that child
engages in brain development activities along with a program to develop Art in it’s
various forms such as music, painting, sketching, dancing drama etc as these are
expressions of life.</p>
            
            </div>

            <div class="col-sm-4 col-md-4">
              <img src="<?php echo e(url('/')); ?>/public/frontend/Infrastructure/brain_development.png" width="100%">
            </div>
          </div>
        </div>
      </div>
    </section>




    <section id="section2">
      <div class="container pb-90 pb-sm-90">
        <div class="section-content">
          <div class="row">
            <div class="col-sm-8 col-md-8">
              <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Student Centered Learning <span class="text-theme-colored3">Using Multiple Intelligence Theory</span></h2>
              <p class="font-15" style="text-align: justify;">We understand that different individuals have different aptitudes. Our faculty utilises
the Multiple Intelligence Theory of Dr. Howard Gardner to make its teaching more
effective and clear. We understand that every child can be benefitted by the
implementation of some or the other intelligence. <br> <br>By using the strongest aptitudes or
&#39;intelligences&#39; as a starting point, our educators educate more effectively by teaching
different students the same topic in different ways, according to their particular
&#39;intelligences&#39;. Through this, each student is given an opportunity to come at par with
what is required. <br><br> Special classes for weaker students, and helping those who need
special attention, in one or the other subject, leads to an overall, broad and complete
educational experience by the child.
              </p>
            
            </div>
            

            <div class="col-sm-4 col-md-4">
              <img src="<?php echo e(url('/')); ?>/public/frontend/infrastructure/student_centered.png">
            </div>
          </div>
        </div>
      </div>
    </section>










  </div>
  <!-- end main-content -->
 <?php echo $__env->make('layouts.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a> </div>
<!-- end wrapper --> 

<!-- Footer Scripts --> 
<!-- JS | Custom script for all pages --> 
<script src="<?php echo e(url('/')); ?>/public/frontend/js/custom.js"></script>

</body>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links
  $("a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
});
</script>
</html>